package ѧУ������;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Homepage extends JFrame implements ActionListener,MouseListener {
	private MyJPanel school;
	private int labelx = 20;
	private int labely = 370;
	private int labelwidth = 250;
	private int labelheight = 30;
	private int space =50;
	String schoolname;
	JLabel[] label = new JLabel[2];
	public Homepage() {
		super("��ҳ");
		this.setSize(980,800);
//		����Լ����Եķֱ���
		Dimension   screensize   =   Toolkit.getDefaultToolkit().getScreenSize();  
//		����Լ��趨�Ľ���ķֱ���
		Dimension   framesize   =   this.getSize();
//		x �� y �趨����Ŀ�ʼλ�ã���֤��������Ļ�м����
	    int   x   =   (int)screensize.getWidth()/2 - (int)framesize.width/2 ;   
	    int   y   =   (int)screensize.getHeight()/2 - (int)framesize.height/2 ;   
//	    �趨�����λ��
	    this.setLocation(x,y);
	    
	    school = new MyJPanel();
	    school.setBounds(0, 0, 980, 340);
	    this.add(school);
	    
	    label[0] = new JLabel("ѧ��ע���¼���");
	    label[0].setFont(new Font("����",1,25));
	    label[0].setBounds(labelx, labely, labelwidth, labelheight);
	    label[0].addMouseListener(this);
	    
	    label[1] = new JLabel("���ӿγ�");
	    label[1].setFont(new Font("����",1,25));
	    label[1].setBounds(labelx, labely+space, labelwidth, labelheight);
	    label[1].addMouseListener(this);
	    
	    
	    for(int i = 0;i<2;i++) {
	    	this.add(label[i]);
	    }
	    
	  
	    this.setDefaultCloseOperation(3);
	    this.setLayout(null);
		this.setVisible(true);
	}
	public ImageIcon setPicture(String schoolname) {
		ImageIcon pic = new ImageIcon("src/ѧУ����ͼƬ/"+schoolname+".png");
		return pic;
	}
	class MyJPanel extends JPanel{
		@Override
		 public void paint(Graphics g) {
			super.paint(g);
			g.drawImage(setPicture(schoolname).getImage(), 0, 0, this);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Homepage();
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==label[0]) {
			label[0].setForeground(Color.green);
			for(int i = 0;i<2;i++) {
				if(i==0)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
			Loginstatus Ls =new Loginstatus();
			Ls.schoolname.setText(schoolname);
		}
		if(e.getSource()==label[1]) {
			label[1].setForeground(Color.green);
			for(int i = 0;i<2;i++) {
				if(i==1)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
