package ѧУ������;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Loginstatus extends JFrame implements ActionListener {
	private int labelx = 30;
	private int labely = 90;
	private int labelheight = 30;
	private int labelwidth =200;
	private int space =60;
	private int numx = 350;
	private int buttonx = 450;
	private int[] cnt = new int[2];
	
	JLabel schoolname;
	JLabel[] label = new JLabel[2];
	JLabel[] num = new JLabel[2];
	JButton[] button = new JButton[2];
	JButton refresh = new JButton("ˢ��");
	JButton add;
	JButton delete;
	
	public Loginstatus() {
		super("ѧ����¼ע�����");
//		����һ�����ڴ�СΪ��Ϊ565����Ϊ400�Ĵ���
		this.setSize(565, 500);
//		���Լ����Ե���Ļ�ֱ���
		Dimension   screensize   =   Toolkit.getDefaultToolkit().getScreenSize();  
//		����Լ��趨�Ľ���ķֱ���
		Dimension   framesize   =   this.getSize();
//		x �� y �趨����Ŀ�ʼλ�ã���֤��������Ļ�м����
	    int   x   =   (int)screensize.getWidth()/2 - (int)framesize.width/2 ;   
	    int   y   =   (int)screensize.getHeight()/2 - (int)framesize.height/2 ;   
//	       �趨�����λ��
	    this.setLocation(x,y); 
//		�������������Ϊnull�ֲ�
		this.setLayout(null);
//		��ͼƬ����Ϊһ����ǩ
		
		schoolname = new JLabel();
		schoolname.setBounds(200, 30, 164, 30);
		schoolname.setFont(new Font("����",1,35));
		this.add(schoolname);
		
		
		label[0] = new JLabel("��ע��ѧ������");
		label[1] = new JLabel("��ע��ѧ������");
		
	    for(int i = 0;i<2;i++) {
		    label[i].setFont(new Font("����",1,25));
		    label[i].setBounds(labelx, labely+i*space, labelwidth, labelheight);
		    this.add(label[i]);
	    }
	    
	    cnt[0] = getLoginOknum();
	 
	    cnt[1] = getLoginNonum();
	   
	    for(int i = 0 ;i<2;i++) {
	    	label[i] = new JLabel();
	    	label[i].setText(String.valueOf(cnt[i]));
	    	label[i].setFont(new Font("����",1,25));
		    label[i].setBounds(numx, labely+i*space, labelwidth, labelheight);
		    this.add(label[i]);
	    }
	    
	    for(int i = 0;i<2;i++) {
	    	button[i] = new JButton("�鿴");
	    	button[i].setFont(new Font("����",1,16));
	    	button[i].setBounds(buttonx, labely+i*space, 66, 24);
	    	button[i].addActionListener(this);
	    	this.add(button[i]);		
	    }
	    
	    add = new JButton("����ѧ��");
	    add.setBounds(20, 300, 84, 26);
	    add.addActionListener(this);
	    this.add(add);
	    
	    delete = new JButton("ɾ��ѧ��");
	    delete.setBounds(20, 360, 84, 26);
	    delete.addActionListener(this);
	    this.add(delete);
	    
	    refresh.setBounds(500, 20, 58, 26);
	    refresh.addActionListener(this);
	    this.add(refresh);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().contentEquals("ˢ��")) {
			this.dispose();
			Loginstatus Ls =new Loginstatus();
			Ls.schoolname.setText(schoolname.getText());
		}
		if(e.getSource()==button[0]) {
			try {
				BufferedReader in  = new BufferedReader(
						new InputStreamReader(
								new FileInputStream("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/�Ѿ�ע��.txt"),"gb18030"));
				String information;
				while((information=in.readLine())!=null) {
					System.out.println(information);
				}
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==button[1]) {
			try {
				BufferedReader in  = new BufferedReader(
						new InputStreamReader(
								new FileInputStream("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/register.txt"),"gb18030"));
				String information;
				while((information=in.readLine())!=null) {
					System.out.println(information);
				}
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==add) {
			new AddStudent();
			
		}

	}
	public int getLoginOknum() {
		int cnt = 0;
		try {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(
							new FileInputStream("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/�Ѿ�ע��.txt")));
			while(br.readLine()!=null) {
				cnt++;
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	public int getLoginNonum() {
		int cnt = 0;
		try {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(
							new FileInputStream("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/register.txt")));
			while(br.readLine()!=null) {
				cnt++;
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	
	public static void main(String[] args) {
		new Loginstatus();
	}
	
}
