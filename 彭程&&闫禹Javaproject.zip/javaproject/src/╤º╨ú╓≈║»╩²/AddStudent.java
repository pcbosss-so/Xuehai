package ѧУ������;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddStudent extends Loginstatus implements ActionListener{
	JLabel school = new JLabel("ѧУ");
	JTextField schoolText = new JTextField();
	JLabel name = new JLabel("ѧ������");
	JTextField nameText = new JTextField();
	JLabel id = new JLabel("ѧ��ѧ��");
	JTextField idText = new JTextField();
	JButton button = new JButton("����");
	
//	����ǩ�ĸ߶���Ϊlabelheight
	private int labelheight = 30;
//	����ǩ1�Ŀ�����Ϊlabelwidth1
	private int labelwidth1 = 60;
//	���˺�����ĳ�����Ϊfieldwidth
	private int fieldwidth = 200;
//	�����±�ǩ�ļ����Ϊspace
	private int space = 50;
	private int label1x = 150;
	private int label1y = 270;
	private int label2x = label1x;
	private int label2y = label1y + space;
	private int label3x = label2x;
	private int label3y = label2y + space;
	private int buttonx = 300;
	private int buttony = label3y + space;
	private int buttonwidth = 60;
	private int buttonheight = 24;
	public AddStudent() {
		this.setLayout(null);
		school.setBounds(label1x, label1y, labelwidth1, labelheight);
		this.add(school);
		
		schoolText.setBounds(label1x+labelwidth1, label1y, fieldwidth, labelheight);
		this.add(schoolText);
		
		id.setBounds(label2x, label2y, labelwidth1, labelheight);
		this.add(id);
		
		idText.setBounds(label2x+labelwidth1, label2y, fieldwidth, labelheight);
		this.add(idText);
		
		name.setBounds(label3x, label3y, labelwidth1, labelheight);
		this.add(name);
		
		nameText.setBounds(label3x+labelwidth1, label3y, fieldwidth, labelheight);
		this.add(nameText);
		 
		button.setBounds(buttonx, buttony, buttonwidth, buttonheight);
		button.addActionListener(this);
		this.add(button);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==add) {
			new AddStudent();
			
		}
		if(e.getActionCommand().contentEquals("����")) {
			try {
				String information = schoolText.getText()+"+"+idText.getText()+"+"+nameText.getText()+"\n";
				BufferedWriter bw = new BufferedWriter(new FileWriter("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/register.txt",true));
				bw.write(information);
				bw.close();
				JOptionPane.showMessageDialog(null, "��洢��ѧ������ϢΪ:\n"
						+ "ѧУ:"+schoolText.getText()+"\n"
								+ "ѧ��:"+idText.getText()+"\n"
										+ "����:"+nameText.getText());
				this.dispose();
				new AddStudent();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			
			
		}
		
	}

}
