
package javaproject;

public class UserMain {
	public static void main(String[] args) {
		new Login();
		
	}
	
}
