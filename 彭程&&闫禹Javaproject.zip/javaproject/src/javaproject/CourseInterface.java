package javaproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CourseInterface extends JFrame implements MouseListener {
	private MyJPanel1 course;
	JLabel school;
	String coursename;
	String schoolname;
	
	private JLabel[] label = new JLabel[6];
	private int labelx = 20;
	private int labely = 300;
	private int labelwidth = 250;
	private int labelheight = 30;
	private int space = 50;
	
	
	public CourseInterface() {
		this.setSize(1500,800);
//		����Լ����Եķֱ���
		Dimension   screensize   =   Toolkit.getDefaultToolkit().getScreenSize();  
//		����Լ��趨�Ľ���ķֱ���
		Dimension   framesize   =   this.getSize();
//		x �� y �趨����Ŀ�ʼλ�ã���֤��������Ļ�м����
	    int   x   =   (int)screensize.getWidth()/2 - (int)framesize.width/2 ;   
	    int   y   =   (int)screensize.getHeight()/2 - (int)framesize.height/2 ;   
//	    �趨�����λ��
	    this.setLocation(x,y);
	    this.setLayout(null);
	    
	    course = new MyJPanel1();
	    course.setBounds(0, 100, 250, 140);
	    this.add(course);
	    
	    school = new JLabel();
		school.setBounds(70, 20, 150, 54);
		school.setFont(new Font("����",1,22));
		this.add(school);
	    
	    label[0] = new JLabel("����");
	    label[0].setFont(new Font("����",1,25));
	    label[0].setBounds(labelx, labely, labelwidth, labelheight);
	    label[0].addMouseListener(this);
	    
	    label[1] = new JLabel("���ֱ�׼");
	    label[1].setFont(new Font("����",1,25));
	    label[1].setBounds(labelx, labely+space, labelwidth, labelheight);
	    label[1].addMouseListener(this);
	    
	    label[2] = new JLabel("�μ�");
	    label[2].setFont(new Font("����",1,25));
	    label[2].setBounds(labelx, labely+2*space, labelwidth, labelheight);
	    label[2].addMouseListener(this);
	    
	    label[3] = new JLabel("��������ҵ");
	    label[3].setFont(new Font("����",1,25));
	    label[3].setBounds(labelx, labely+3*space, labelwidth, labelheight);
	    label[3].addMouseListener(this);
	    
	    label[4] = new JLabel("����");
	    label[4].setFont(new Font("����",1,25));
	    label[4].setBounds(labelx, labely+4*space, labelwidth, labelheight);
	    label[4].addMouseListener(this);
	    
	    label[5] = new JLabel("������");
	    label[5].setFont(new Font("����",1,25));
	    label[5].setBounds(labelx, labely+5*space, labelwidth, labelheight);
	    label[5].addMouseListener(this);
	    
	    for(int i = 0;i<5;i++) {
	    	this.add(label[i]);
	    }
	    
	  
		
		this.setVisible(true);
		
	}
	public ImageIcon setPicture(String filename) {
		ImageIcon pic = new ImageIcon("src/ѧУͼ��/"+filename+".png");
		return pic;
	}
	class MyJPanel1 extends JPanel{
		@Override
		 public void paint(Graphics g) {
			super.paint(g);
			g.drawImage(setPicture(coursename).getImage(), 0, 0, this);
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource()==label[0]) {
			label[0].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==0)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
		if(e.getSource()==label[1]) {
			label[1].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==1)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
		if(e.getSource()==label[2]) {
			label[2].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==2)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
		if(e.getSource()==label[3]) {
			label[3].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==3)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
		if(e.getSource()==label[4]) {
			label[4].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==4)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
		if(e.getSource()==label[5]) {
			label[5].setForeground(Color.green);
			for(int i = 0;i<5;i++) {
				if(i==5)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
