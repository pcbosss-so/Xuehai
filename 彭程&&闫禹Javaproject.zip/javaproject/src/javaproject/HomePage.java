package javaproject;

import java.awt.Font;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.ImageIcon;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class HomePage extends JFrame implements ActionListener{
//	���������Ϊ60������
	JButton goback;
	JButton bn1;
	JButton bn2;
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	JButton button5;
	JButton button6;
	JButton button7;
	JButton button8;
	JButton button9;
	JTextField search;
	JTextField schoolMessage;
	JButton searchbutton;
	JButton MySchool;
	JButton myself;
	JButton button10;
	JButton button11;
	JButton button12;
	JButton button13;
	
	private int button1x = 60;
	private int button1y = 1000;
	private int space = 60;
	private int button1width = 84;
	private int button1height = 30;
	private int[] buttony = new int[9];
	private int searchx = 450;
	private int searchy = 60;
	private int searchwidth = 500;
	private int searchheight = 40;
	private int searchbuttonx = searchx+searchwidth;
	private int searchbuttony = 60;
	private int searchbuttonwidth = 60;
	private int searchbuttonheight = 40;
	private JPanel contentPane;
	public HomePage() {
		JFrame frame = new JFrame("��ҳ");
		setBg();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 710);
		init();
		this.setLayout(null);
		this.setSize(1500,900);
		for(int i = 0 ;i<buttony.length;i++) {
			buttony[i] = (30 + i*(space+button1height));
			
		}
		goback = new JButton("����");
		goback.setBounds(0, 0, 60, 30);
		goback.addActionListener(this);
		this.add(goback);
		
		button2 = new JButton("����׼��");
		button2.setBounds(button1x, buttony[1], button1width, button1height);
		this.add(button2);
		button3 =new JButton("���Ҿ�Ʒ");
		button3.setBounds(button1x, buttony[2], button1width, button1height);
		this.add(button3);
		button4 = new JButton("��ʦר��");
		button4.setBounds(button1x, buttony[3], button1width, button1height);
		this.add(button4);
		button5 = new JButton("Ӣ��ѧϰ");
		button5.setBounds(button1x, buttony[4], button1width, button1height);
		this.add(button5);
		button6 = new JButton("��ĩ��ϰ");
		button6.setBounds(button1x, buttony[5], button1width, button1height);
		this.add(button6);
		button7 = new JButton("�����");
		button7.setBounds(button1x, buttony[6], button1width, button1height);
		this.add(button7);
		button8 = new JButton("�˶�����");
		button8.setBounds(button1x, buttony[7], button1width, button1height);
		this.add(button8);
		button9 = new JButton("����..");
		button9.setBounds(button1x, buttony[8], button1width, button1height);
		this.add(button9);
		search = new JTextField();
		search.setBounds(searchx-50, searchy, searchwidth, searchheight);
		this.add(search);
		
		searchbutton = new JButton("����");
		searchbutton.addActionListener(this);
		searchbutton.setBounds(searchbuttonx-50, searchbuttony, searchbuttonwidth, searchbuttonheight);
		this.add(searchbutton);
		MySchool = new JButton("ѧУר������");
		MySchool.addActionListener(this);
		MySchool.setFont(new Font("����",1,20));
		MySchool.setBounds(1200, 40, 180, 40);
		this.add(MySchool);
		this.setLocationRelativeTo(null); 
		this.setDefaultCloseOperation(3);
		this.setVisible(true);
	    bn1 = new JButton("�γ�1");
	    bn1.setBounds(searchx-100, 700, 300, 200);
	    this.add(bn1);
		bn1.addActionListener(this);
	    bn2 = new JButton("�γ�2");
		bn2.setBounds(searchx+350, 700, 300, 200);
		this.add(bn2);
		bn2.addActionListener(this);
		myself = new JButton("��������");
		myself.setBounds(searchx+800, searchy+150, 100, 50);
		this.add(myself);
		myself.addActionListener(this);
		button11 = new JButton("�ҵĿγ�");
		button11.setBounds(searchx+800, searchy+250, 100, 50);
		this.add(button11);
		button11.addActionListener(this);
		button12 = new JButton("�ҵ�ѧУ��");
		button12.setBounds(searchx+800, searchy+350, 100, 50);
		this.add(button12);
		button12.addActionListener(this);
		button13 = new JButton("��������");
		button13.setBounds(searchx+800, searchy+450, 100, 50);
		this.add(button13);
		button13.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
		String classname = search.getText();
		
        if(e.getSource()==bn1)
        {
            this.dispose();
            new MyFrame();
        }
		if(e.getSource()==bn2) {
        	this.dispose();
        	new MyFrame();
        }
		if(e.getSource()==goback) {
			this.dispose();
			new Login();
		}
		if(e.getActionCommand().equals("ѧУר������")) {
			this.dispose();
			new MySchoolHomePage();
		}
		if(e.getActionCommand().contentEquals("����")) {
			String filename = "src/�γ���Ϣ/"+classname+".txt";
			File file = new File(filename);
			if(!file.exists()) {
				JOptionPane.showMessageDialog(null,"û�����ſγ�");
			}
			else {
				try {
					BufferedReader in = new BufferedReader(
							new InputStreamReader(
									new FileInputStream(filename)));
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "�Ҳ����ļ�");
					e1.printStackTrace();
				}
				CourseInformation CI = new CourseInformation();
				CI.filename = classname;
				CI.courseName.setText(classname);
				try {
					CI.school.setText(readLineVarFile(filename, 2));
					for(int i = 0; i<CI.information.length;i++) {
						CI.information[i].setText(readLineVarFile(filename,(i+3)));
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		}
		if(e.getActionCommand().contentEquals("��������")) {
			try {
				new MyselfFrame();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getActionCommand().contentEquals("��������")) {
			AboutUs a = AboutUs.getInstance();
			a.showMessage();
		}
    }
	public void init() {
		contentPane = new JPanel();
		contentPane.setOpaque(false);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setVisible(true);
	}
	public void setBg() {
		((JPanel)this.getContentPane()).setOpaque(false);
		ImageIcon img = new ImageIcon("src/images/���.PNG");
		JLabel background = new JLabel(img);
		this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
		background.setBounds(300, 150, img.getIconWidth()-200, img.getIconHeight());
	}
	static String readLineVarFile(String fileName, int lineNumber) throws IOException { 
        BufferedReader reader = new BufferedReader(new InputStreamReader( 
                        new FileInputStream(fileName),"utf8")); 
        String line = reader.readLine(); 
        
        int num = 0; 
        while (line != null) { 
                if (lineNumber == ++num) { 
                	
                       break; 
                } 
                line = reader.readLine();
        } 
        reader.close();
		return line; 
        
	} 
	public static void main(String[] args) {
		new HomePage();
	}
}
