package javaproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class CourseInformation extends JFrame implements ActionListener {
	
	
	private MyJPanel picture;
	JLabel school;
	JLabel courseName;
	JLabel information[] = new JLabel[5];
	private JButton join;
	String filename;

	public CourseInformation() {
	
		this.setSize(900,500);
//		����Լ����Եķֱ���
		Dimension   screensize   =   Toolkit.getDefaultToolkit().getScreenSize();  
//		����Լ��趨�Ľ���ķֱ���
		Dimension   framesize   =   this.getSize();
//		x �� y �趨����Ŀ�ʼλ�ã���֤��������Ļ�м����
	    int   x   =   (int)screensize.getWidth()/2 - (int)framesize.width/2 ;   
	    int   y   =   (int)screensize.getHeight()/2 - (int)framesize.height/2 ;   
//	    �趨�����λ��
	    this.setLayout(null);
	    this.setLocation(x,y);
	   
		picture = new MyJPanel();
		picture.setBounds(0, 30, 400, 225);
		this.add(picture);
		
		school = new JLabel();
		school.setBounds(450, 20, 100, 50);
		school.setFont(new Font("����",1,22));
		this.add(school);
		
		courseName = new JLabel();
		courseName.setBounds(450, 50, 300, 50);
		courseName.setFont(new Font("����",1,22));
		this.add(courseName);
		
		information[0] = new JLabel();
		information[0].setBounds(450, 100, 500, 30);
		information[0].setFont(new Font("����",1,15));
		this.add(information[0]);
		information[1] = new JLabel();
		information[1].setBounds(450, 130, 500, 30);
		information[1].setFont(new Font("����",1,15));
		this.add(information[1]);
		information[2] = new JLabel();
		information[2].setBounds(450, 160, 500, 30);
		information[2].setFont(new Font("����",1,15));
		this.add(information[2]);
		information[3] = new JLabel();
		information[3].setBounds(450, 190, 500, 30);
		information[3].setFont(new Font("����",1,15));
		this.add(information[3]);
		information[4] = new JLabel();
		information[4].setBounds(450, 220, 500, 30);
		information[4].setFont(new Font("����",1,15));
		this.add(information[4]);
		
		join = new JButton("�μ�");
		join.addActionListener(this);
		join.setBounds(600, 330, 100, 50);
		join.setBackground(Color.ORANGE);
		join.setFont(new Font("����",1,25));
		join.addActionListener(this);
		
		
		this.add(join);
		
		this.setVisible(true);
	}
	
	public ImageIcon setPicture(String filename) {
		ImageIcon pic = new ImageIcon("src/�γ�ͼƬ/"+filename+".png");
		return pic;
	}
	class MyJPanel extends JPanel{
		@Override
		 public void paint(Graphics g) {
			super.paint(g);
			g.drawImage(setPicture(filename).getImage(), 0, 0, this);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("�μ�")) {
			CourseInterface CI = new CourseInterface();
			CI.coursename = courseName.getText();
			CI.school.setText(school.getText());
			CI.schoolname = school.getText();
					
		}
	}
}
