package javaproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class informationFrame extends JFrame implements ActionListener{
	private JTextField jf1;
	private JTextField jf2;
	private JTextField jf3;
	private JLabel college;
	private JLabel major;
	private JLabel email;
	private JPanel contentPane;
	private JButton button;
	private JButton back;
	public informationFrame() {
		JFrame frame = new JFrame("������Ϣ");
		init();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 600);
		college = new JLabel("ѧԺ��");
		this.add(college);
		college.setBounds(100, 25, 40, 30);
		jf1 = new JTextField();
		this.add(jf1);
		jf1.setBounds(140, 25, 100, 35);
		major = new JLabel("רҵ��");
		this.add(major);
		major.setBounds(100, 75, 40, 30);
		jf2 = new JTextField();
		this.add(jf2);
		jf2.setBounds(140, 75, 100, 35);
		email = new JLabel("�����ʼ���");
		this.add(email);
		email.setBounds(80, 125, 80, 30);
		jf3 = new JTextField();
		this.add(jf3);
		jf3.setBounds(140, 125, 100, 35);
		button = new JButton("����");
		this.add(button);
		button.setBounds(120, 200, 60, 30);
		button.addActionListener(this);
		back = new JButton("����");
		this.add(back);
		back.setBounds(200, 200, 60, 30);
		back.addActionListener(this);
	}
	public static void main(String[] args) {
		new informationFrame();
	}
	public void init() {
		contentPane = new JPanel();
		contentPane.setOpaque(false);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			try {
				PrintWriter on = new PrintWriter(
						new FileWriter(
								new File("src/ѧ����Ϣ/ѧ����Ϣ.txt")));
				on.println(jf1.getText());
				on.println(jf2.getText());
				on.println(jf3.getText());
				on.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		if(e.getSource()==back) {
			this.dispose();
			try {
				new MyselfFrame();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
