package javaproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MyFrame extends JFrame implements ActionListener{
    private JPanel contentPane;
    JButton goback;
    public MyFrame() {
    	this.setLayout(null);
    	goback = new JButton("����");
		goback.setBounds(0, 0, 60, 30);
		goback.addActionListener(this);
		this.add(goback);
    	setBg();
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setBounds(100, 100, 1000, 600);
    	init();
    }
    public void init() {
    	contentPane = new JPanel();
    	contentPane.setOpaque(false);
    	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    	setContentPane(contentPane);
    	contentPane.setLayout(null);
    	this.setVisible(true);
    }
    public void setBg() {
    	((JPanel)this.getContentPane()).setOpaque(false);
    	ImageIcon img = new ImageIcon("src/images/���н���ͼƬ.PNG");
    	JLabel background = new JLabel(img);
    	this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
    	background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("����")){
			this.dispose();
			new HomePage();
		}
		if(e.getActionCommand().equals("ѧУר������")) {
			this.dispose();
			new MySchoolHomePage();
		}
	}
}
