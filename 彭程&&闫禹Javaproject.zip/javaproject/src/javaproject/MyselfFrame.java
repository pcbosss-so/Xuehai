package javaproject;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MyselfFrame extends JFrame implements ActionListener{
	JButton bn1;
	private JPanel contentPane;
	private JLabel name;
	private JLabel school;
	private JLabel idNumber;
	private JLabel college;
	private JLabel major;
	private JLabel email;
	private JButton button;
	public MyselfFrame() throws IOException {
		JFrame frame = new JFrame("��������");
		setBounds(100, 100, 500, 400);
		setBg();
		init();
		bn1 = new JButton("����");
		this.add(bn1);
		bn1.setBounds(325, 60, 80, 50);
		bn1.addActionListener(this);
		BufferedReader in = new BufferedReader(
				new FileReader(
						new File("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/Login.txt")));
		BufferedReader on = new BufferedReader(
				new FileReader(
						new File("src/ѧУע���¼��Ϣ/�Ĵ���ѧ/�Ѿ�ע��.txt")));
		String line1 = in.readLine();
		StringTokenizer st = new StringTokenizer(line1,"$$$");
		String result = st.nextToken();
		String line2 = "";
		String schoolString = "";
		String idNumberString = "";
		String nameString = "";
		while((line2 = on.readLine()) != null) {
			StringTokenizer sr = new StringTokenizer(line2, "+");
			schoolString = sr.nextToken();
			idNumberString = sr.nextToken();
			nameString = sr.nextToken();
			if(result.equals(idNumberString)) {
				name = new JLabel("������" + nameString);
				this.add(name);
				name.setBounds(150 ,15 ,100, 40);
				school = new JLabel("ѧУ��" + schoolString);
				this.add(school);
				school.setBounds(150, 40, 100, 40);
				idNumber = new JLabel("ѧ�ţ�" + idNumberString);
				this.add(idNumber);
				idNumber.setBounds(150, 65 ,800, 40);
				break;
			}
		}
		BufferedReader reader = new BufferedReader(
				new FileReader(
						new File("src/ѧ����Ϣ/ѧ����Ϣ.txt")));
		String message1 = "";
		String message2 = "";
		String message3 = "";
		String message = "";
		int j = 0;
		String line = "";
		while((line = reader.readLine()) != null) {
			if(j==0) {
				message1 = line;
			}
			if(j==1) {
				message2 = message2 + line;
			}
			if(j==2) {
				message3 = message3 + line;
			}
			j+=1;
		}
		in.close();
		college = new JLabel("ѧԺ��" + message1);
		this.add(college);
		college.setBounds(150, 90, 100, 40);
		major = new JLabel("רҵ��" + message2);
		this.add(major);
		major.setBounds(150, 115, 300, 40);
		email = new JLabel("e-mail��" + message3);
		this.add(email);
		email.setBounds(150, 140, 300, 40);
		button = new JButton("������Ϣ");
		this.add(button);
		button.setBounds(150, 250, 100, 50);
		button.addActionListener(this);
	}
	
	public void init() {
		contentPane = new JPanel();
		contentPane.setOpaque(false);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setVisible(true);
	}
	public void setBg() {
		((JPanel)this.getContentPane()).setOpaque(false);
		ImageIcon img = new ImageIcon("src/images/ͷ��.png");
		JLabel background = new JLabel(img);
		this.getLayeredPane().add(background,new Integer(Integer.MAX_VALUE));
		background.setBounds(25, 25, img.getIconWidth(), img.getIconHeight());
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			new informationFrame();
			this.dispose();
			
		}
		if(e.getSource()==bn1) {
			this.dispose();
			
		}
	}
}
