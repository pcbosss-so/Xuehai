package javaproject;

import javax.swing.JButton;

public class MySchoolHomePage extends HomePage {
	public MySchoolHomePage() {
		
		
	}
	

}
