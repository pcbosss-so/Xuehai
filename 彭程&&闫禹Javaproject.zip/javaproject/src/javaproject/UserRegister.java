package javaproject;

import javax.swing.JFrame;

public class UserRegister extends JFrame {
	
	public UserRegister() {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
