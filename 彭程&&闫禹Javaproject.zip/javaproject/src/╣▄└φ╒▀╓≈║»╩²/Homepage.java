package ������������;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

import ѧУ������.Loginstatus;

public class Homepage extends JFrame implements MouseListener{
	private int labelx = 30;
	private int labely = 50;
	private int labelwidth = 250;
	private int labelheight = 30;
	private int space =50;
	JLabel[] label = new JLabel[2];
	public Homepage() {
		super("��������ҳ");
		this.setSize(980,800);
//		����Լ����Եķֱ���
		Dimension   screensize   =   Toolkit.getDefaultToolkit().getScreenSize();  
//		����Լ��趨�Ľ���ķֱ���
		Dimension   framesize   =   this.getSize();
//		x �� y �趨����Ŀ�ʼλ�ã���֤��������Ļ�м����
	    int   x   =   (int)screensize.getWidth()/2 - (int)framesize.width/2 ;   
	    int   y   =   (int)screensize.getHeight()/2 - (int)framesize.height/2 ;   
//	    �趨�����λ��
	    this.setLocation(x,y);
	    this.setLayout(null);
	    label[0] = new JLabel("����ѧУ");
	    label[0].setFont(new Font("����",1,25));
	    label[0].setBounds(labelx, labely, labelwidth, labelheight);
	    label[0].addMouseListener(this);
	    
	    label[1] = new JLabel("���ӿγ�");
	    label[1].setFont(new Font("����",1,25));
	    label[1].setBounds(labelx, 100, labelwidth, labelheight);
	    label[1].addMouseListener(this);
	    
	    for(int i = 0;i<2;i++) {
	    	this.add(label[i]);
	    }
	    
	    this.setDefaultCloseOperation(3);
	    this.setVisible(true);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==label[0]) {
			label[0].setForeground(Color.green);
			for(int i = 0;i<2;i++) {
				if(i==0)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
			SchoolLoginstatus SLs =new SchoolLoginstatus();
		}
		if(e.getSource()==label[1]) {
			label[1].setForeground(Color.green);
			for(int i = 0;i<2;i++) {
				if(i==1)
					continue;
				else {
					label[i].setForeground(Color.black);
				}
			}
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
