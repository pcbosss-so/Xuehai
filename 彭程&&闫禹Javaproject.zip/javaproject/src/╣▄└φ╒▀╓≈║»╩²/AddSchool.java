package ������������;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import ѧУ������.AddStudent;

public class AddSchool extends SchoolLoginstatus implements ActionListener {

	JLabel school = new JLabel("ѧУ");
	JTextField schoolText = new JTextField();
	JLabel id = new JLabel("����");
	JTextField idText = new JTextField();
	JButton button = new JButton("����");
	
//	����ǩ�ĸ߶���Ϊlabelheight
	private int labelheight = 30;
//	����ǩ1�Ŀ�����Ϊlabelwidth1
	private int labelwidth1 = 60;
//	���˺�����ĳ�����Ϊfieldwidth
	private int fieldwidth = 200;
//	�����±�ǩ�ļ����Ϊspace
	private int space = 50;
	private int label1x = 150;
	private int label1y = 270;
	private int label2x = label1x;
	private int label2y = label1y + space;
	private int label3x = label2x;
	private int label3y = label2y + space;
	private int buttonx = 300;
	private int buttony = label3y + space;
	private int buttonwidth = 60;
	private int buttonheight = 24;
	public AddSchool() {
		this.setLayout(null);
		school.setBounds(label1x, label1y, labelwidth1, labelheight);
		this.add(school);
		
		schoolText.setBounds(label1x+labelwidth1, label1y, fieldwidth, labelheight);
		this.add(schoolText);
		
		id.setBounds(label2x, label2y, labelwidth1, labelheight);
		this.add(id);
		
		idText.setBounds(label2x+labelwidth1, label2y, fieldwidth, labelheight);
		this.add(idText);
	
		button.setBounds(buttonx, buttony, buttonwidth, buttonheight);
		button.addActionListener(this);
		this.add(button);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==add) {
			new AddSchool();
			
		}
		if(e.getActionCommand().contentEquals("����")) {
			try {
				String information = schoolText.getText()+"+"+idText.getText()+"\n";
				BufferedWriter bw = new BufferedWriter(new FileWriter("src/ѧУע���¼��Ϣ/registerschool.txt",true));
				bw.write(information);
				bw.close();
				JOptionPane.showMessageDialog(null, "�����ӵ�ѧУΪ:\n"
						+ "ѧУ:"+schoolText.getText()+"\n"
								+ "����:"+idText.getText());
				this.dispose();
				new AddSchool();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			
			
		}
		
	}

}
